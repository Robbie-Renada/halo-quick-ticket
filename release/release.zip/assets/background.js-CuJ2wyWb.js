chrome.runtime.onInstalled.addListener(()=>{});chrome.runtime.onMessage.addListener((r,s,e)=>(e({status:"ok"}),!0));
