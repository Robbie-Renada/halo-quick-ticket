import './assets/background.js-CuJ2wyWb.js';
